file install.sh ae phai install bang cach ko go
./install.sh S
bash install.sh D
ae luu y nhe!
chuc anh em cai ubuntu thanh cong !
ma tool da teset,anh em dung so loi tool cai ubuntu
tam biet!
